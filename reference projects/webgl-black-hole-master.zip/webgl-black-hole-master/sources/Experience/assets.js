export default [
    {
        name: 'base',
        data: {},
        items:
        [
            // { name: 'cupolaModel', source: '/assets/models/cupola.glb' },
        ]
    }
]